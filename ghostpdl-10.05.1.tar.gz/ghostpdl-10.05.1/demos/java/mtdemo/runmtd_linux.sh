#!/bin/bash

java -cp "gsjava.jar:." Main "$ARG1"
