#pragma once

// Use to disable multithreading support, ghostpdl must be compiled with multithreading
// enabled as well
//#define GSJNI_NO_MT