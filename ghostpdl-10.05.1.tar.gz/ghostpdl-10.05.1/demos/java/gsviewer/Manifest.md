Manifest-Version: 1.0
Class-Path: gsjava.jar ./
Main-Class: com.artifex.gsviewer.Main
