#!/bin/bash

export LD_PRELOAD=/usr/lib/libgpdl.so.9

java -jar gsviewer.jar