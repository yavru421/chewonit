#!/bin/bash

export LD_PRELOAD=./libgpdl.dylib

java -jar gsviewer.jar