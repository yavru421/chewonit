Manifest-Version: 1.0
Class-Path: ./